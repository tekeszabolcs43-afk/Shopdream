# SHOPDREAM – webshop kezdőcsomag

## Futtatás
1. Csomagold ki a ZIP-et.
2. Nyisd meg az `index.html` fájlt egy modern böngészőben.

## Mi működik?
- Reszponzív, magyar nyelvű fekete/neonrózsaszín felület
- Termékkategóriák és keresés
- Minta termékkártyák, árak és akciójelölések
- Kosár: hozzáadás, mennyiség módosítása, részösszeg és végösszeg
- Hírlevél űrlap demó-visszajelzéssel

## Fontos, élesítés előtt
Ez egy front-end prototípus. A termékek, árak, értékelések és kedvezmények demonstrációs adatok. A kosár csak a böngésző memóriájában működik, a rendelés nem kerül elküldésre, és fizetés nem történik.

Valódi értékesítéshez szükséges:
- szerveroldali termék- és rendeléskezelés, adatbázis
- biztonságos pénztár és fizetési szolgáltató (pl. Stripe vagy Barion), tesztelés után éles kulcsokkal
- készletkezelés, szállítási díjak és rendelési visszaigazolás
- adatkezelési tájékoztató, ÁSZF, elállási és jótállási tájékoztatók, impresszum
- cookie-kezelés és adatvédelmi megfelelés, ahol szükséges
- domain, HTTPS és tárhely

A látható jogi oldalak most csak helyőrzők. Ne indíts éles értékesítést a szükséges kereskedelmi és jogi beállítások nélkül.
